# Mest Tire — UI/UX Audit Patch Handoff

本次更新由 Claude 根据 2026-04-23 UI/UX 审计报告（`ui-ux-audit.md`）生成。所有改动集中在 `patches/src/` 目录下，结构与生产仓库 `jiahaowen666-droid/Mest-tire` 完全镜像，可直接覆盖对应路径。

---

## 🚀 交给 Claude Code 的 Prompt（直接复制整段给她）

> 你好，我这里有一个 `patches/` 目录，里面包含了针对 Mest Tire Next.js 项目的 UI/UX 审计修复。请按以下步骤执行：
>
> 1. 克隆我的仓库 `jiahaowen666-droid/Mest-tire`（默认分支）。
> 2. 从我附上的 `patches/` 目录（结构与仓库 `src/` 镜像）把每个文件**整体覆盖**到仓库对应路径。涉及的文件清单：
>    - `src/app/globals.css`
>    - `src/app/layout.tsx`（如未同步，请只同步新增的 CJK fallback 行）
>    - `src/app/HomeContent.tsx`
>    - `src/app/HomeCTA.tsx`
>    - `src/components/HeroSection.tsx`
>    - `src/components/StatsSection.tsx`
>    - `src/components/ApplicationSection.tsx`
>    - `src/components/ProductOrbit.tsx`
>    - `src/components/FAQSection.tsx`
> 3. 运行 `pnpm install && pnpm dev`（或 `npm`），本地启动确认无 TypeScript / Tailwind 报错。重点检查：
>    - `@layer components` 里的 `btn-lg / btn-primary / btn-on-dark / btn-on-brand / btn-on-brand-out` 是否被 Tailwind 编译出来（Tailwind v4 `@import "tailwindcss"` 下 `@layer components` 需要 `@utility` 或保留 preflight 顺序，请验证；如必要改为直接在 JSX 用长 className，不要改动视觉）。
>    - `StatsSection` 和 `HomeCTA` 背景色由 `#f97316` 改成 `#b45309`（amber-700），白字通过 WCAG AA。
>    - `ProductOrbit` 的 emoji 已全部替换为 SVG 图标；鼠标悬停到任意节点时**外圈虚线环会立即停转**（之前是 bug）。
>    - `ProductOrbit` 在 `lg`（1024–1279px）下 orbit 尺寸为 420px，`xl` 以上恢复 520px。
>    - `FAQSection` 展开动画用的是 Framer Motion `AnimatePresence`，不再是 `max-h-96`。
>    - 所有橙色按钮 hover/active 有轻微 `scale(0.98)` 按压反馈。
> 4. 提交 commit：
>    ```
>    git checkout -b fix/ui-ux-audit-2026-04
>    git add .
>    git commit -m "fix(ui): apply 2026-04 UI/UX audit patches
>
>    - WCAG AA: orange bg #f97316 → #b45309 on Stats + CTA
>    - Replace emoji with stroke-1.5 SVG icons in ProductOrbit
>    - Fix ProductOrbit rotation pause bug on hover
>    - Responsive orbit size (420px lg → 520px xl)
>    - Unified button tokens (.btn-lg / .btn-primary etc.)
>    - H2 hierarchy: 4xl/5xl major vs 3xl/4xl supporting
>    - font-black → font-extrabold on supporting h2/h3
>    - FAQ max-height → AnimatePresence height:auto
>    - CJK font fallback (Noto Sans SC / PingFang / YaHei)
>    - Raise text-gray-500 → 600 / white/50 → 70/80 → 100 for AA
>    - focus-visible rings on orbit + FAQ buttons"
>    git push origin fix/ui-ux-audit-2026-04
>    ```
> 5. 开一个 Pull Request 指向 `main`，标题 `fix(ui): 2026-04 UI/UX audit patches`，正文引用本文件 "审计对照清单" 部分。
> 6. 等 Vercel preview 部署好，给我 preview URL。
>
> 如果任何一步遇到问题（TypeScript 报错、Tailwind v4 语法、translations 缺字段等），**先停下来告诉我**，不要自行改动设计。

---

## 审计对照清单（13 条 issue ↔ 代码位置）

| # | 审计条目 | 优先级 | 状态 | 改动位置 |
|---|---------|------|------|---------|
| 1.1 | 所有 h2 字号相同 | 高 | ✅ | 主模块 `text-4xl sm:text-5xl`；辅助模块 `text-3xl sm:text-4xl`，全部用 `font-extrabold`——`ApplicationSection` / `ProductOrbit` / `FAQSection` / `HomeContent` |
| 1.3 | Hero 徽章对比度过低 | 中 | ✅ | `HeroSection.tsx`: `text-white/50` → `text-white/70`；scroll indicator 也提到 `/60` |
| 2.1 | 白字 + 橙底 WCAG 失败 | 🔴 高 | ✅ | `StatsSection.tsx` + `HomeCTA.tsx`: `bg-[#f97316]` → `bg-[#b45309]`；`text-white/80` → `text-white` |
| 2.3 | gray-400 正文不达标 | 中 | ✅ | `HomeContent.tsx`: `text-gray-500/600` → `text-gray-600/700` |
| 3.1 | `text-[10px]` 魔法数字 | 中 | ✅ | `ApplicationSection` + `ProductOrbit`: 全部 `text-xs` |
| 3.2 | h2 全站 `font-black` | 低 | ✅ | 辅助模块 h2/h3 改为 `font-extrabold` |
| 3.3 | CJK 字体缺失 | 中 | ✅ | `globals.css` body/h* 加 `"Noto Sans SC","PingFang SC","Microsoft YaHei"` fallback |
| 4.1 | Orbit 520px 溢出 lg | 高 | ✅ | `ProductOrbit.tsx`: `w-[420px] h-[420px] xl:w-[520px] xl:h-[520px]`；SVG 用 `viewBox` + `width="100%"` |
| 4.2 | Applications `gap-3` 不一致 | 低 | ✅ | `ApplicationSection.tsx`: `gap-3` → `gap-4` |
| 4.3 | 按钮 padding 有 5 种 | 中 | ✅ | `globals.css` 新增 `.btn-lg / .btn-md / .btn-sm / .btn-primary / .btn-on-dark / .btn-on-brand / .btn-on-brand-out` |
| 5.1 | Orbit 暂停 bug | 🔴 高 | ✅ | `ProductOrbit.tsx`: `animate` 和 `transition` 都响应 `isPaused` |
| 5.2 | 按钮无按压反馈 | 中 | ✅ | `.btn-base` 加 `active:scale-[0.98]` + `transition-all duration-150` |
| 5.3 | FAQ `max-height` 卡顿 | 低 | ✅ | `FAQSection.tsx`: `AnimatePresence` + `height: 'auto'` |
| 5.4 | Orbit 缺 focus-visible | 中 | ✅ | 节点按钮 + FAQ 按钮均加 `focus-visible:ring-2 focus-visible:ring-[#f97316] focus-visible:ring-offset-2` |
| 6.1 | Emoji 图标 | 🔴 高 | ✅ | `ProductOrbit.tsx` 6 个 SVG（与 `ApplicationSection` 风格一致，strokeWidth 1.5）。**Products 页面需后续单独处理** |
| 6.3 | section 对齐不一致 | 低 | ✅ | `HomeContent.tsx` "Why Us" 从居中改为左对齐 |

---

## 未覆盖的条目（需要额外上下文才能改）

- **#6.1 (续)** — `src/app/products/ProductsContent.tsx` 未导入本项目，所以它的 11 个 emoji 还没替换。Claude Code 可以照 `ProductOrbit` 里的 SVG 模式再补 5 个图标（e-scooter / lawn mower / trailer / bicycle / e-motorcycle）。
- **#2.2** — 7 次背景切换。合并 section 会影响翻译文案结构，建议等产品侧决定后再做。
- **#6.2** — 卡片风格统一需要重构 `ProductsContent`，同样等单独任务。

---

## 视觉验证要点（PR 提交后）

1. Stats 区块背景更深（暖棕调），数字和 label 都清晰可读。
2. CTA 区块同上。
3. Orbit 悬停任意节点：**虚线外圈立刻静止**，数字指示线平滑切换。
4. Orbit 在 1024px 视窗下不挤压右侧文案。
5. FAQ 展开长答案不再被截断。
6. 所有按钮点击瞬间有轻微缩放。
7. 切换到中文时，字形不再 fallback 到系统衬线字体。
